from ksu_app.services.data_loader import load_repository
from ksu_app.services.planner import (
    build_course_lookup,
    build_manual_schedule_rows,
    compute_remaining_requirements,
    recommend_next_term,
)


def test_recommendations_respect_prereqs():
    repo = load_repository()
    program = repo["programs"]["BS Computer Science"]
    course_lookup = build_course_lookup(repo["courses"])
    remaining = compute_remaining_requirements(program, ["CS 1301", "CSE 1321", "MATH 1190"])
    plan = recommend_next_term(
        remaining_requirements=remaining,
        course_lookup=course_lookup,
        completed_courses=["CS 1301", "CSE 1321", "MATH 1190"],
        target_credits=12,
        preferred_term="Fall 2026",
        sections=repo["sections"],
        professors=repo["professors"],
    )
    assert "CS 1302" in plan or "CSE 1322" in plan
    assert "CS 3304" not in plan


def test_manual_schedule_rows_include_crn():
    repo = load_repository()
    course_lookup = build_course_lookup(repo["courses"])
    rows = build_manual_schedule_rows(
        selected_courses=["CS 1301"],
        selected_term="Fall 2026",
        course_lookup=course_lookup,
        sections=repo["sections"],
        professors=repo["professors"],
    )
    assert rows
    assert "crn" in rows[0]
