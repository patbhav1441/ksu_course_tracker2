from __future__ import annotations

import streamlit as st

BACKGROUND_IMAGE = "https://images.unsplash.com/photo-1498243691581-b145c3f54a5a?auto=format&fit=crop&w=1600&q=80"


def inject_theme() -> None:
    st.markdown(
        f"""
        <style>
            :root {{
                --ksu-black: #0b0d12;
                --ksu-charcoal: #11151d;
                --ksu-panel: rgba(12, 14, 18, 0.74);
                --ksu-gold: #f0b323;
                --ksu-gold-soft: rgba(240, 179, 35, 0.18);
                --ksu-cream: #f8f5ef;
                --ksu-border: rgba(255,255,255,0.12);
                --ksu-text: #f4f7fb;
                --ksu-muted: rgba(244,247,251,0.76);
            }}
            .stApp {{
                background:
                    linear-gradient(180deg, rgba(7, 9, 14, 0.72), rgba(7, 9, 14, 0.94)),
                    url('{BACKGROUND_IMAGE}') center/cover fixed no-repeat;
                color: var(--ksu-text);
            }}
            [data-testid="stSidebar"] {{
                background: linear-gradient(180deg, rgba(10,12,18,0.97), rgba(10,12,18,0.93));
                border-right: 1px solid var(--ksu-border);
            }}
            [data-testid="stMetric"] {{
                background: rgba(12, 14, 18, 0.74);
                border: 1px solid var(--ksu-border);
                border-radius: 20px;
                padding: 12px;
                backdrop-filter: blur(10px);
            }}
            .stTabs [data-baseweb="tab-list"] {{ gap: 0.55rem; }}
            .stTabs [data-baseweb="tab"] {{
                background: rgba(12, 14, 18, 0.74);
                border-radius: 999px;
                border: 1px solid var(--ksu-border);
                color: white;
                padding: 0.75rem 1rem;
            }}
            .stTabs [aria-selected="true"] {{
                background: linear-gradient(90deg, rgba(240,179,35,0.24), rgba(240,179,35,0.12));
                border-color: rgba(240,179,35,0.55);
            }}
            .hero-wrap {{
                margin-bottom: 1rem;
                min-height: 300px;
                border-radius: 30px;
                overflow: hidden;
                background:
                    linear-gradient(115deg, rgba(10,12,18,0.92), rgba(10,12,18,0.46)),
                    url('{BACKGROUND_IMAGE}') center/cover no-repeat;
                border: 1px solid rgba(255,255,255,0.1);
                box-shadow: 0 30px 100px rgba(0,0,0,0.35);
            }}
            .hero-overlay {{ padding: 2.3rem; max-width: 780px; }}
            .hero-overlay h1 {{ font-size: 3.2rem; line-height: 1.02; margin: 0.35rem 0 0.75rem 0; color: white; }}
            .hero-overlay p {{ font-size: 1.06rem; color: var(--ksu-muted); margin: 0; }}
            .hero-badge {{
                display: inline-flex;
                align-items: center;
                gap: 0.4rem;
                padding: 0.45rem 0.8rem;
                border-radius: 999px;
                background: rgba(240,179,35,0.14);
                color: #ffd978;
                border: 1px solid rgba(240,179,35,0.35);
                font-size: 0.86rem;
                letter-spacing: 0.02em;
            }}
            .glass-card, .course-card {{
                background: var(--ksu-panel);
                border: 1px solid rgba(255,255,255,0.10);
                border-radius: 22px;
                padding: 1rem 1.1rem;
                backdrop-filter: blur(12px);
                box-shadow: 0 18px 50px rgba(0,0,0,0.22);
                margin-bottom: 0.9rem;
            }}
            .course-card-complete {{ border-color: rgba(240,179,35,0.46); }}
            .course-card-top {{ display: flex; gap: 0.75rem; align-items: flex-start; margin-bottom: 0.9rem; color: white; }}
            .course-code {{ font-size: 1.03rem; font-weight: 700; }}
            .course-title, .muted-copy {{ color: var(--ksu-muted); }}
            .course-meta-grid, .signal-grid, .stat-grid {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(140px, 1fr)); gap: 0.7rem; }}
            .course-meta-grid span, .signal-grid div, .stat-grid div {{
                background: rgba(255,255,255,0.03);
                border: 1px solid rgba(255,255,255,0.06);
                border-radius: 16px;
                padding: 0.8rem;
            }}
            .stat-label {{ color: var(--ksu-muted); font-size: 0.82rem; text-transform: uppercase; letter-spacing: 0.04em; }}
            .stat-value {{ color: white; font-size: 1rem; font-weight: 700; }}
            .section-kicker {{ color: #ffd978; text-transform: uppercase; letter-spacing: 0.08em; font-size: 0.78rem; margin-bottom: 0.4rem; }}
            .professor-card h3 {{ margin-bottom: 0.25rem; color: white; }}
            .professor-header {{ display: flex; justify-content: space-between; gap: 1rem; align-items: flex-start; margin-bottom: 1rem; }}
            .prof-chip-wrap {{ display: flex; flex-wrap: wrap; gap: 0.5rem; justify-content: flex-end; }}
            .prof-chip {{
                background: rgba(240,179,35,0.14);
                color: #ffe29d;
                border: 1px solid rgba(240,179,35,0.32);
                border-radius: 999px;
                padding: 0.35rem 0.7rem;
                font-size: 0.85rem;
            }}
            .stButton button, .stDownloadButton button {{
                border-radius: 999px;
                border: 1px solid rgba(240,179,35,0.4);
                background: rgba(17,19,24,0.85);
                color: white;
            }}
            .stDataFrame, [data-testid="stDataFrame"] {{
                background: rgba(12,14,18,0.72);
                border-radius: 20px;
                border: 1px solid rgba(255,255,255,0.08);
                overflow: hidden;
            }}
            .stSelectbox label, .stMultiSelect label, .stSlider label, .stCheckbox label, .stRadio label, .stTextInput label {{ color: white !important; }}
        </style>
        """,
        unsafe_allow_html=True,
    )
