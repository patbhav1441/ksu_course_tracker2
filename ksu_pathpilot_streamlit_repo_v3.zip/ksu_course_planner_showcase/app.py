from __future__ import annotations

import streamlit as st

from ksu_app.components.renderers import (
    render_course_card,
    render_header,
    render_plan_table,
    render_professor_card,
    render_program_summary,
    render_schedule_table,
)
from ksu_app.services.data_loader import load_repository
from ksu_app.services.planner import (
    PREFERENCE_PRESETS,
    build_course_lookup,
    build_course_recommendation_rows,
    build_full_path,
    build_manual_schedule_rows,
    compute_remaining_requirements,
    infer_term_offerings,
    professor_signal_summary,
    recommend_next_term,
    recommend_sections_for_courses,
)
from ksu_app.theme.styles import inject_theme

st.set_page_config(page_title="KSU PathPilot", page_icon="🦉", layout="wide", initial_sidebar_state="expanded")
inject_theme()

repo = load_repository()
programs = repo["programs"]
courses = repo["courses"]
sections = repo["sections"]
professors = repo["professors"]

course_lookup = build_course_lookup(courses)
program_names = sorted(programs.keys())
term_names = sorted({s["term"] for s in sections})
all_course_codes = sorted(course_lookup.keys())
term_offerings = infer_term_offerings(sections)

render_header(
    hero_title="KSU PathPilot",
    hero_subtitle="A polished KSU themed planner for degree maps, prerequisite aware course recommendations, professor intelligence, and term by term section planning.",
)

with st.sidebar:
    st.markdown("## Planner controls")
    selected_program = st.selectbox("Major or minor", program_names)
    selected_term = st.selectbox("Planning term", term_names, index=max(0, len(term_names) - 1))
    completed_courses = st.multiselect(
        "Completed courses",
        all_course_codes,
        help="Pick every course already finished or confidently finishing before the selected term.",
    )
    max_next_term = st.slider("Target credits for next term", min_value=3, max_value=18, value=12, step=1)
    preference_profile = st.radio("Recommendation style", list(PREFERENCE_PRESETS.keys()), index=0)
    show_only_open = st.toggle("Only show open sections", value=False)
    selected_courses_override = st.multiselect(
        "Manual course selection for this term",
        options=sorted({s["course_code"] for s in sections if s["term"] == selected_term}),
        help="If you choose courses here, the app ranks professors and sections for those exact classes.",
    )

program = programs[selected_program]
remaining = compute_remaining_requirements(program, completed_courses)
remaining_credit_total = sum(int(course_lookup.get(code, {}).get("credits") or 0) for code in remaining)
next_term_plan = recommend_next_term(
    remaining_requirements=remaining,
    course_lookup=course_lookup,
    completed_courses=completed_courses,
    target_credits=max_next_term,
    preferred_term=selected_term,
    sections=sections,
    professors=professors,
    only_open_sections=show_only_open,
    preference_profile=preference_profile,
)
path = build_full_path(
    remaining_requirements=remaining,
    course_lookup=course_lookup,
    completed_courses=completed_courses,
    starting_term=selected_term,
)
next_term_rows = build_course_recommendation_rows(
    next_term_plan=next_term_plan,
    course_lookup=course_lookup,
    selected_term=selected_term,
    sections=sections,
    professors=professors,
    only_open=show_only_open,
    preference_profile=preference_profile,
)
selected_courses_for_rank = selected_courses_override or next_term_plan
section_rankings = recommend_sections_for_courses(
    selected_courses=selected_courses_for_rank,
    selected_term=selected_term,
    sections=sections,
    professors=professors,
    only_open=show_only_open,
    preference_profile=preference_profile,
)
manual_rows = build_manual_schedule_rows(
    selected_courses=selected_courses_for_rank,
    selected_term=selected_term,
    course_lookup=course_lookup,
    sections=sections,
    professors=professors,
    preference_profile=preference_profile,
    only_open=show_only_open,
)

hero_left, hero_mid, hero_right = st.columns([1.35, 1, 1])
with hero_left:
    render_program_summary(program, remaining, completed_courses, remaining_credit_total)
with hero_mid:
    st.metric("Completed courses", len(completed_courses))
    st.metric("Remaining requirements", len(remaining))
with hero_right:
    visible_sections = [
        s for s in sections if s["term"] == selected_term and (not show_only_open or int(s.get("seats_available") or 0) > 0)
    ]
    st.metric("Visible sections", len(visible_sections))
    st.metric("Recommended credits", sum(int(course_lookup[c].get("credits") or 0) for c in next_term_plan if c in course_lookup))

st.divider()

map_tab, explore_tab, prof_tab, path_tab = st.tabs(["Program map", "Term scheduler", "Professor intel", "Path builder"])

with map_tab:
    st.subheader("Requirements, prerequisites, and sequencing")
    st.caption("Academic maps are guidance. Official catalog and registration data should still be treated as the decision source of truth.")
    for requirement in program.get("requirements", []):
        render_course_card(
            requirement,
            course_lookup.get(requirement["course_code"]),
            taken=requirement["course_code"] in completed_courses,
            term_offerings=sorted(term_offerings.get(requirement["course_code"], [])),
        )

with explore_tab:
    st.subheader(f"Term scheduler for {selected_term}")
    filter_choices = st.multiselect(
        "Filter section table by course",
        sorted({s["course_code"] for s in visible_sections}),
        default=selected_courses_for_rank[: min(5, len(selected_courses_for_rank))],
        key="table_filters",
    )
    table_sections = visible_sections
    if filter_choices:
        table_sections = [s for s in table_sections if s["course_code"] in filter_choices]

    merged_rows = []
    for section in table_sections:
        professor = professors.get(section.get("professor_id") or "", {})
        merged_rows.append(
            {
                **section,
                "overall_rating": professor.get("overall_rating", "N/A"),
                "difficulty": professor.get("difficulty", "N/A"),
                "num_ratings": professor.get("num_ratings", 0),
            }
        )
    render_schedule_table(
        merged_rows,
        caption="Use this table as the registration shortlist. It includes CRN, section, seat counts, modality, and professor signals.",
        csv_name="ksu_term_sections.csv",
    )

    st.subheader("Best section matches for chosen courses")
    render_schedule_table(
        manual_rows,
        caption="Top ranked sections blend professor quality, difficulty, available seats, and modality.",
        csv_name="ksu_ranked_sections.csv",
    )

with prof_tab:
    st.subheader("Professor intelligence for this term")
    st.caption("This deployed app should read a prebuilt professor dataset. Keep any collection or transformation pipeline outside the frontend repo.")
    available_prof_courses = sorted({s["course_code"] for s in sections if s["term"] == selected_term})
    chosen_prof_course = st.selectbox("Choose a course for professor comparison", available_prof_courses)
    ranked_for_course = section_rankings.get(chosen_prof_course) or recommend_sections_for_courses(
        [chosen_prof_course],
        selected_term,
        sections,
        professors,
        only_open=show_only_open,
        preference_profile=preference_profile,
    ).get(chosen_prof_course, [])
    if not ranked_for_course:
        st.info("No professor backed section data is available for that course in the selected term.")
    for rec in ranked_for_course[:5]:
        professor = rec.professor
        if not professor:
            continue
        render_professor_card(professor, professor_signal_summary(professor), rec.section)

with path_tab:
    st.subheader("Recommended next semester")
    render_plan_table(next_term_rows, title="Recommended courses and best professor backed sections", csv_name="ksu_next_term_plan.csv")

    st.subheader("Multi term path preview")
    if not path:
        st.info("No future path could be generated from the current inputs.")
    for term, planned_courses in path.items():
        rows = build_course_recommendation_rows(
            next_term_plan=planned_courses,
            course_lookup=course_lookup,
            selected_term=term,
            sections=sections,
            professors=professors,
            only_open=False,
            preference_profile=preference_profile,
        )
        render_plan_table(rows, title=term)

st.divider()
with st.expander("System design and production notes"):
    st.markdown(
        """
        **Source priority**
        1. KSU catalog for course rules, prerequisites, and corequisites.
        2. KSU academic maps for suggested sequencing.
        3. KSU schedule of classes for live section details, CRNs, modality, and seat counts.
        4. A separate professor intelligence dataset refresh for sentiment and rating signals.

        **Production shape**
        Keep the Streamlit frontend read only. Refresh source files with ETL jobs, validate schema, then publish stable JSON or parquet snapshots into the app.

        **Current limitation**
        This build is production styled and logic hardened, but the shipped data bundle is still a demo dataset. It needs full KSU program and schedule ingestion before a public student release.
        """
    )
